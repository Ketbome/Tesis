#define IEEE_8087
#define Arith_Kind_ASL 1
