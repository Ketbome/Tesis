
====================================
Other Resources
====================================

- In French: `An introduction to Ibex and Minibex by the OGRE team of LS2N (PDF) <http://www.ibex-lib.org/formation_minibex.pdf>`_.
